package com.example.kyl3g.sunhacksnov2018.Callback;

import com.example.kyl3g.sunhacksnov2018.Objects.Grocery;
import com.example.kyl3g.sunhacksnov2018.Objects.Recipes;

import java.util.List;

public interface ResultCallback {
    void callback(List<Grocery> callback);
}
