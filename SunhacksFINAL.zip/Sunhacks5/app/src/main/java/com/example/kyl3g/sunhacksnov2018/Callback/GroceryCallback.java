package com.example.kyl3g.sunhacksnov2018.Callback;

import com.example.kyl3g.sunhacksnov2018.Objects.Grocery;

public interface GroceryCallback {
    void callback(Grocery callback);
}
