package com.example.kyl3g.sunhacksnov2018.Callback;

import com.example.kyl3g.sunhacksnov2018.Objects.Recipes;

public interface RecipeCallback {
    void callback(Recipes callback);
}
