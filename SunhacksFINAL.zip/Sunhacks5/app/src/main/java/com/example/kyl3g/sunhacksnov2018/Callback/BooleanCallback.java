package com.example.kyl3g.sunhacksnov2018.Callback;

public interface BooleanCallback {
    void callback(boolean callback);
}
