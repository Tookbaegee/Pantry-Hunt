package com.example.kyl3g.sunhacksnov2018.Callback;

import com.example.kyl3g.sunhacksnov2018.Objects.Recipes;

import java.util.List;

public interface RecipeListCallback {
    void callback(List<Recipes> callback);
}
