package com.example.kyl3g.sunhacksnov2018.Callback;

import com.example.kyl3g.sunhacksnov2018.Objects.Grocery;

import java.util.List;

public interface GroceryListCallback {
    void callback(List<Grocery> callback);
}
